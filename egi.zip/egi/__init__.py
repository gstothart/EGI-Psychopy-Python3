

"""
    Python interface to interact with EGI Netstation

    simple.py is a wrapper for a single-threaded version,
    threaded.py is a, eh, threaded version,
    may be there would also be a "multiprocessed" one.

    Some examples will either follow or live in some separate
    test files here.
   
    Based on v0.9.0 . Ported to Python 3 by:
    email: aat63@bath.ac.uk
"""

__version__ = '3.0.0'
